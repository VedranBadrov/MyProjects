from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
# Create your views here.

def login(request):
    if request.method == 'POST':
        password1 = request.POST['password'] 
        email = request.POST['email']

        user = auth.authenticate(email=email, password=password)

        if user is not None: 
            auth.login(request, user)
            return redirect("index.html")
        else:
            messages.info(request, 'Invalid credentials')
            return redirect('sign-in.html')
    else:
        return render(request,'sign-up.html')


def register(request):


    if request.method == 'POST':
        first_name = request.POST['first_name']
        second_name = request.POST['second_name']
        username = request.POST['username']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        email = request.POST['email']

        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request,'Username Taken')
                return redirect ('register')
            elif User.objects.filter(email=email).exists():
                messages.info(request,'Email Taken')
                return redirect('register')
            else:
                user = User.objects.create_user(username=username, password=password1, email=email, first_name=first_name, last_name=last_name)
                user.save();
                print('user created')
                return redirect('sign-in.html')
        else:
            messages.info(request,'Password not matching')
            return redirect('sign-up.html')
        return redirect('/')
    else:
        return render(request, 'sign-up.html')